import os,sys,time,subprocess,json,signal
from pathlib import Path
label,count,mode=sys.argv[1],int(sys.argv[2]),sys.argv[3]
root=Path('/tmp/yeyu-flake-evidence'); burners=[]; results=[]
cpus=sorted(os.sched_getaffinity(0))[:2]
if mode=='load': os.sched_setaffinity(0,cpus)
try:
 if mode=='load':
  for _ in cpus: burners.append(subprocess.Popen(['yes'],stdout=subprocess.DEVNULL))
 command=['xvfb-run','-a','pnpm','test'] if mode=='suite' else ['xvfb-run','-a','pnpm','exec','node','--test','--test-concurrency=1','--experimental-strip-types',(sys.argv[4] if len(sys.argv)>4 else 'tests/shared-viewer-regression.test.ts')]
 for i in range(1,count+1):
  start=time.monotonic()
  with (root/f'{label}-{i:03}.log').open('w') as log:
   p=subprocess.run(command,cwd='/home/yusicheng/project/learning_app/demo',stdout=log,stderr=subprocess.STDOUT)
  row=dict(run=i,exit=p.returncode,seconds=round(time.monotonic()-start,3));results.append(row)
  (root/f'{label}.json').write_text(json.dumps(dict(command=command,mode=mode,cpus=cpus if mode=='load' else 'all',burners=len(burners),results=results),indent=2))
  print(label,row,flush=True)
  if (root/f'{label}.stop').exists(): break
finally:
 for p in burners:p.terminate()
 for p in burners:p.wait()
 print('cleaned CPU workers', [p.pid for p in burners],flush=True)
