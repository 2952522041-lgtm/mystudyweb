import subprocess,time,json
from pathlib import Path
root=Path('/tmp/yeyu-flake-evidence')
while 'cleaned CPU workers' not in (root/'progressive-final.progress').read_text(): time.sleep(1)
for label,n,mode,extra in [('progressive-original-after',20,'load',[str(root/'progressive-original-after.test.ts')]),('after-normal',50,'normal',[]),('after-load',50,'load',[]),('after-suite',5,'suite',[])]:
 with (root/f'{label}.progress').open('w') as log:
  result=subprocess.run(['python',str(root/'run.py'),label,str(n),mode,*extra],stdout=log,stderr=subprocess.STDOUT)
 if result.returncode: raise SystemExit(result.returncode)
 print(label,'completed',flush=True)
